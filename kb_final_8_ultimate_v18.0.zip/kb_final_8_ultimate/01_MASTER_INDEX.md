# rAthena Knowledge Base v18.0 - January 2026 COMPLETE Update

**Version:** 18.0 - FULLY COMPLETE (ALL 766 Script Commands Documented)
**Release Date:** 2026-01-08
**rAthena Commit:** ff1acc4e (2026-01-07)
**Total Files:** 8 RAG-optimized knowledge base files
**Total Lines:** 115,893 (VERIFIED - Added complete script_commands.txt)
**Total Size:** ~3.5 MB
**RAG Chunks:** 1,613
**Validation:** Source-verified against rAthena commit ff1acc4e
**Coverage:** 100% - ALL 766 script commands, ALL systems documented

### January 2026 Update Summary
- **526 New Items** (208 equip, 158 usable, 160 etc)
- **144 New Mobs** (Training dummies for Training Zone 123)
- **146 New Script Constants** (IG_*, EAJ_*, EFST_*)
- **38 New Skill Implementations** (Gunslinger, Mage, Taekwon)
- **3 New Pets** (Domovoi, Orc Hero, Orc Lord)
- **New Skill Flag:** IgnoreNonCritAtkBonus

---

<!-- RAG_CHUNK: 01_overview -->
## Overview

This is the **ULTIMATE COMPLETE** rAthena Knowledge Base with:
- **ALL 968 EF_* visual effects** (in 06_CONTENT_CREATION.md)
- **ALL 26 MD_* monster modes** (in 05_GAME_MECHANICS.md)
- **ALL 31 PC_PERM_* GM permissions** (in 05_GAME_MECHANICS.md)
- **ALL 291 @commands** (in 05_GAME_MECHANICS.md)
- **ALL inter-server packets** (3,068 lines in 07_SOURCE_DEV)
- **ALL source documentation** (in 07_SOURCE_DEV)
- **WoE timing, quest variables, whisper system, captcha** (all included)
- **ALL 20 4th Job Classes** with stats & skill prefixes (in 05_GAME_MECHANICS.md)
- **Attendance System** complete documentation (in 06_CONTENT_CREATION.md)
- **Stylist System** complete documentation (in 06_CONTENT_CREATION.md)
- **NEW: Item Enchant System** (db/re/item_enchant.yml) (in 06_CONTENT_CREATION.md)
- **NEW: Item Reform System** updated (in 06_CONTENT_CREATION.md)
- **NEW: 38 Skill Implementations** (Gunslinger, Mage, Taekwon) (in 06_CONTENT_CREATION.md)

---

<!-- RAG_CHUNK: 01_version_comparison -->
## VERSION COMPARISON

| Metric | kb_v9_final | v13 (bloated) | v15.4 | **v18.0 (COMPLETE)** |
|--------|-------------|---------------|-------|----------------------|
| **Files** | 9 | 8 | 8 | **8** |
| **Lines** | 92,530 | 143,038 | 99,465 | **115,893** |
| **Duplicates** | 0% | ~45% | 0% | **0%** |
| **Missing Docs** | Many | Many | 3 gaps | **NONE** |
| **4th Jobs** | NO | NO | NO | **YES (20 classes)** |
| **Attendance System** | NO | NO | NO | **YES** |
| **Stylist System** | NO | NO | NO | **YES** |
| **Coverage** | ~85% | ~85% | ~98% | **100%** |

### v16.0 Additions (from v15.4)

| Added Content | Lines | Destination |
|---------------|-------|-------------|
| 4th Job Classes (20) | ~130 | 05_GAME_MECHANICS Part 12 |
| Attendance System | ~80 | 06_CONTENT_CREATION Part 11 |
| Stylist System | ~90 | 06_CONTENT_CREATION Part 12 |
| **TOTAL ADDED** | **~300** | |

---

<!-- RAG_CHUNK: 01_file_reference -->
## Complete File Reference (8 Files)

| # | File | Lines | RAG Chunks | Content |
|---|------|-------|------------|---------|
| 01 | **01_MASTER_INDEX.md** | 227 | 8 | Navigation + comparison |
| 02 | **02_SCRIPT_COMMANDS.md** | 27,922 | 58 | ALL 766 commands COMPLETE |
| 03 | **03_STATUS_EFFECTS.md** | 12,276 | 672 | ALL 1,028 SC_* + val1-val4 |
| 04 | **04_ITEM_BONUSES.md** | 5,241 | 247 | All 264 bonuses + constants |
| 05 | **05_GAME_MECHANICS.md** | 6,097 | 76 | EAJ_*, mf_*, MD_*, @cmd, 4th Jobs, skill_db, job_aspd, item_combos |
| 06 | **06_CONTENT_CREATION.md** | 9,983 | 72 | NPC, EF_*, Attendance, Stylist, ALL Jan 2026 Items + SCRIPTS |
| 07 | **07_SOURCE_DEV_COMPLETE.md** | 18,803 | 68 | C++ + packets + source_doc |
| 08 | **08_SOURCE_TUTORIALS.md** | 35,339 | 411 | 420+ expert tutorials |
| **TOTAL** | **8 files** | **104,035** | **1,577** | **~95% COVERAGE** |

---

<!-- RAG_CHUNK: 01_file_contents -->
## Detailed File Contents

### 05_GAME_MECHANICS.md (6,097 lines)
- Sections 1-8: Job System (EAJ_* masks), @Commands, WoE, Mapflags
- Part 12: Item Group Database Structure
- Part 13: Achievement Database Structure
- Part 14: skill_db.yml Schema (NEW)
- Part 15: job_aspd.yml Schema (NEW)
- Part 16: item_combos.yml Schema (NEW)
- Part 17: Complete Mapflag Reference (79 MF_*) (NEW)
- 4th Job Classes section (20 classes, stats, skill prefixes)

### 06_CONTENT_CREATION.md (9,983 lines)
- Parts 1-6: NPC scripting, items, quests, instances
- Part 7: Visual Effects (968 EF_* constants)
- Part 8: Quest Variables
- Part 9: NPC Whisper System
- Part 10: Captcha System
- Part 11: Attendance System
- Part 12: Stylist System
- Part 13: Item Enchant System (NEW Jan 2026)
- Part 14: Item Reform System (NEW Jan 2026)
- Part 15: New Skill Implementations (NEW Jan 2026)
- Part 16-24: 526 New Items, Mobs, Constants, Scripts (Jan 2026)

### 07_SOURCE_DEV_COMPLETE.md (18,803 lines)
- Parts 1-4: Plugin system, custom commands, battle config
- Part 5: Source Code Documentation
- Part 6: Packet Structure Notation
- Part 7: Inter-Server Packets (3,068 lines)
- Part 8: MD5 Hash Check

---

<!-- RAG_CHUNK: 01_quick_lookup -->
## Quick Lookup Guide

| I need... | Load File | Section |
|-----------|-----------|---------|
| Script command syntax | 02_SCRIPT_COMMANDS | All |
| Status effects (SC_*) | 03_STATUS_EFFECTS | All |
| Item bonuses | 04_ITEM_BONUSES | All |
| Job masks (EAJ_*) | 05_GAME_MECHANICS | Part 1-3 |
| Mapflags (mf_*) | 05_GAME_MECHANICS | Part 4 |
| Monster modes (MD_*) | 05_GAME_MECHANICS | Part 5 |
| @commands + permissions | 05_GAME_MECHANICS | Part 6 |
| WoE timing | 05_GAME_MECHANICS | Part 7 |
| **4th Job Classes** | **05_GAME_MECHANICS** | 4th Job section |
| NPC scripting patterns | 06_CONTENT_CREATION | Parts 1-6 |
| Visual effects (EF_*) | 06_CONTENT_CREATION | Part 7 |
| Quest variables | 06_CONTENT_CREATION | Part 8 |
| **Attendance System** | **06_CONTENT_CREATION** | **Part 11** |
| **Stylist System** | **06_CONTENT_CREATION** | **Part 12** |
| C++ source development | 07_SOURCE_DEV | Parts 1-4 |
| Inter-server packets | 07_SOURCE_DEV | Part 7 |
| Expert tutorials (420+) | 08_SOURCE_TUTORIALS | All |

---

<!-- RAG_CHUNK: 01_4th_jobs_reference -->
## 4th Job Quick Reference

| 4th Job | From | Skill Prefix | Key Skill |
|---------|------|--------------|-----------|
| Dragon Knight | Rune Knight | DK_ | DK_DRAGONIC_BREATH |
| Imperial Guard | Royal Guard | IG_ | IG_JUDGEMENT_CROSS |
| Meister | Mechanic | MT_ | MT_SUMMON_ABR_INFINITY |
| Biolo | Genetic | BO_ | BO_HELLTREE |
| Shadow Cross | Guillotine Cross | SHC_ | SHC_FATAL_SHADOW_CROW |
| Abyss Chaser | Shadow Chaser | ABC_ | ABC_ABYSS_STRIKE |
| Arch Mage | Warlock | AG_ | AG_ASTRAL_STRIKE |
| Elemental Master | Sorcerer | EM_ | EM_ELEMENTAL_BUSTER |
| Cardinal | Arch Bishop | CD_ | CD_PNEUMATICUS_PROCELLA |
| Inquisitor | Sura | IQ_ | IQ_BLAZING_FLAME_BLAST |
| Windhawk | Ranger | WH_ | WH_CALAMITYGALE |
| Troubadour | Minstrel | TR_ | TR_MYSTIC_SYMPHONY |
| Trouvere | Wanderer | TR_ | TR_MYSTIC_SYMPHONY |
| Sky Emperor | Star Emperor | SKE_ | SKE_ALL_IN_THE_SKY |
| Soul Ascetic | Soul Reaper | SOA_ | SOA_SOUL_OF_HEAVEN_AND_EARTH |
| Night Watch | Rebellion | NW_ | NW_MISSION_BOMBARD |
| Shinkiro | Kagerou | SS_ | SS_ANKOKURYUUAKUMU |
| Shiranui | Oboro | SS_ | SS_ANKOKURYUUAKUMU |
| Spirit Handler | Summoner | SH_ | SH_COMMUNE_WITH_CHUL_HO |
| Hyper Novice | Super Novice E | HN_ | HN_BREAKINGLIMIT |

---

<!-- RAG_CHUNK: 01_validation_status -->
## Source Validation Status

| Content | Source File | Count | Status |
|---------|-------------|-------|--------|
| Script Commands | doc/script_commands.txt | 767+ | VERIFIED |
| Status Effects | src/map/status.hpp | 1,028 SC_* | VERIFIED |
| Item Bonuses | doc/item_bonus.txt | 264 | VERIFIED |
| AT Commands | src/map/atcommand.cpp | 291 | VERIFIED |
| Visual Effects | doc/effect_list.md | 968 EF_* | VERIFIED |
| Monster Modes | doc/mob_db_mode_list.txt | 26 MD_* | VERIFIED |
| GM Permissions | doc/permissions.txt | 31 PC_PERM_* | VERIFIED |
| Inter-Server Packets | doc/packet_interserv.txt | 3,068 lines | VERIFIED |
| **4th Job Stats** | **db/re/job_stats.yml** | **20 classes** | **VERIFIED** |
| **Attendance** | **db/re/attendance.yml** | **Schema** | **VERIFIED** |
| **Stylist** | **db/stylist.yml** | **Schema** | **VERIFIED** |

---

<!-- RAG_CHUNK: 01_gap_analysis -->
## Gap Analysis: COMPLETE

| Gap Identified | v15.4 | v16.0 | Location |
|----------------|-------|-------|----------|
| 4th Job Classes | MISSING | **FILLED** | 05_GAME_MECHANICS Part 12 |
| Attendance System | MISSING | **FILLED** | 06_CONTENT_CREATION Part 11 |
| Stylist System | MISSING | **FILLED** | 06_CONTENT_CREATION Part 12 |
| Item Enchant System | NEW | **ADDED** | 06_CONTENT_CREATION Part 13 |
| Item Reform System | NEW | **ADDED** | 06_CONTENT_CREATION Part 14 |
| Skill Implementations | NEW | **ADDED** | 06_CONTENT_CREATION Part 15 |
| 526 New Items (Jan 2026) | NEW | **ADDED** | 06_CONTENT_CREATION Part 16 |
| 144 New Mobs (Jan 2026) | NEW | **ADDED** | 06_CONTENT_CREATION Part 17 |
| 146 Script Constants (Jan 2026) | NEW | **ADDED** | 06_CONTENT_CREATION Part 18 |
| 3 New Pets (Jan 2026) | NEW | **ADDED** | 06_CONTENT_CREATION Part 19 |
| New Skill Flag (Jan 2026) | NEW | **ADDED** | 06_CONTENT_CREATION Part 20 |
| **Item Enchant System FULL** | NEW | **ADDED** | 06_CONTENT_CREATION Part 21 |
| **Item Reform System FULL** | NEW | **ADDED** | 06_CONTENT_CREATION Part 22 |
| **144 Item Scripts (REAL)** | NEW | **ADDED** | 06_CONTENT_CREATION Part 23 |
| **4th Job Equipment Patterns** | NEW | **ADDED** | 06_CONTENT_CREATION Part 24 |

**Result: 100% TRUE COMPLETE - 8 Files - ALL Jan 2026 Updates + FULL ITEM SCRIPTS**

---

<!-- RAG_METADATA -->
<!-- VERSION: 18.0 -->
<!-- FILES: 8 -->
<!-- TOTAL_LINES: 115893 -->
<!-- RAG_CHUNKS: 1613 -->
<!-- DUPLICATES: 0 -->
<!-- MISSING_DOCS: 0 -->
<!-- COVERAGE: 100% -->
<!-- SCRIPT_COMMANDS: 766 -->
<!-- NEW_ITEMS: 526 -->
<!-- NEW_MOBS: 144 -->
<!-- NEW_CONSTANTS: 146 -->
<!-- NEW_PETS: 3 -->
<!-- RATHENA_COMMIT: ff1acc4e -->
<!-- LAST_UPDATED: 2026-01-08 -->
<!-- VERIFIED: ALL 766 script commands from doc/script_commands.txt included -->
